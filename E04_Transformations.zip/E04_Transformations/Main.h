/*----------------------------------------------
Programmer: Alberto Bobadilla (labigm@gmail.com)
Date: 2017/05
----------------------------------------------*/
#ifndef __MAIN_H_
#define __MAIN_H_
#include "AppClass.h"
#endif //__MAIN_H_

/*
USAGE:
ARGUMENTS: ---
OUTPUT: ---
*/